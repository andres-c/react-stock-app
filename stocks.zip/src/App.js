import './App.css';

import Main from './pages/Main';

const App = () => {
  return (
    <div className="App">
      <header className="App-header">
        <Main />
      </header>
    </div>
  );
};

export default App;
